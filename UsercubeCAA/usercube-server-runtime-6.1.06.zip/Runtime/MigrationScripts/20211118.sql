﻿ ALTER TABLE "UP_PolicySimulations" ADD "RiskDeletedCount" INT NULL;
 GO
 ALTER TABLE "UP_PolicySimulations" ADD "RiskAddedCount" INT NULL;
