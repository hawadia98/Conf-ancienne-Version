﻿UPDATE UD_ConfigurationFiles SET FilePath=REPLACE(filepath, '\', '/')
GO
