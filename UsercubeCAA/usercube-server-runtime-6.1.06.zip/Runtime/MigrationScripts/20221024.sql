IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L1') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L1" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L2') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L2" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L3') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L3" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L4') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L4" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L5') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L5" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L6') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L6" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L7') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L7" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L8') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L8" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L9') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L9" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L10') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L10" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L11') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L11" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L12') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L12" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L13') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L13" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L14') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L14" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L15') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L15" NVARCHAR(442) NULL;
END
GO

IF COL_LENGTH('dbo.UJ_TaskInstances', 'DisplayName_L16') IS NULL
BEGIN
ALTER TABLE "UJ_TaskInstances"
    ADD "DisplayName_L16" NVARCHAR(442) NULL;
END
GO