﻿BEGIN
    UPDATE s SET "C1"='false' FROM "UM_Settings" s WHERE "Identifier"='MailSettings'
END
GO
