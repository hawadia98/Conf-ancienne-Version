ALTER TABLE "UW_WorkflowInstances" NOCHECK CONSTRAINT "FK_WorkflowInstances_CurrentActivityInstance";
GO