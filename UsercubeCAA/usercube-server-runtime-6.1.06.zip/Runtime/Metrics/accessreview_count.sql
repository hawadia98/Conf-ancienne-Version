﻿/* Counts of the access review tables */
SELECT 'AccessCertificationCampaign_Count', COUNT(*) FROM US_AccessCertificationCampaigns;
SELECT 'AccessCertificationItem_Count', COUNT(*) FROM US_AccessCertificationItems;
