﻿## Fichier integration CSV for mass Add Profiles
## Usercube - V0.51 - 01/06/2022


# â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ•—   â–ˆâ–ˆâ–ˆâ•—
# â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ•‘
# â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â–ˆâ–ˆâ–ˆâ–ˆâ•”â–ˆâ–ˆâ•‘
# â–ˆâ–ˆâ•”â•â•â•â• â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘â•šâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘
# â–ˆâ–ˆâ•‘     â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘ â•šâ•â• â–ˆâ–ˆâ•‘
# â•šâ•â•     â•šâ•â•  â•šâ•â•â•šâ•â•  â•šâ•â•â•šâ•â•  â•šâ•â•â•šâ•â•     â•šâ•â•
                                           
param (
    [switch] $help,
    [parameter(Mandatory = $true)][string] $ProfileFile
)
if ($help) {
    write-host "Add_Profile_API.ps1 -ProfileFile <String> [-help] [-Verbose]

Options:
 -ProfileFile <String> Sets the path of the CSV profiles entries file
Shared Options:
 -help  Show help information
 -Verbose 
"
    Break
}

# if ([string]::IsNullOrEmpty($ProfileFile)) { 
#     $ProfileFile = "C:/UsercubeCAGIP/WORK/Assign.csv"
# }

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12, [Net.SecurityProtocolType]::Tls11


# â–ˆâ–ˆâ•—   â–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ•—     â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—
# â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•‘     â–ˆâ–ˆâ•”â•â•â•â•â•â–ˆâ–ˆâ•”â•â•â•â•â•
# â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘     â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—
# â•šâ–ˆâ–ˆâ•— â–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•‘     â–ˆâ–ˆâ•”â•â•â•  â•šâ•â•â•â•â–ˆâ–ˆâ•‘
#  â•šâ–ˆâ–ˆâ–ˆâ–ˆâ•”â• â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•‘
#   â•šâ•â•â•â•  â•šâ•â•  â•šâ•â•â•šâ•â•  â•šâ•â•â•šâ•â•â•šâ•â•  â•šâ•â•â•šâ•â•â•â•â•â• â•šâ•â•â•â•â•â•â•â•šâ•â•â•â•â•â•â•â•šâ•â•â•â•â•â•â•
                                                                    
## Environnement
$EnvironmentPath = Split-Path $PSScriptRoot -parent
. "$EnvironmentPath\Powershell\Environnement.ps1"

## â•¦  â”Œâ”€â”â”Œâ”€â”â”Œâ”€â”
## â•‘  â”‚ â”‚â”‚ â”¬â””â”€â”
## â•©â•â•â””â”€â”˜â””â”€â”˜â””â”€â”˜

$date = (Get-Date)
$start = $date.ToString("yyyyMMddHHmmss")
$filetrace = Join-Path -Path $log -ChildPath "Add_Profile_API_$start.log"
Start-Transcript $filetrace | out-null
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Start Add_Profile_API process"

## â•¦â•”â•â”Œâ”€â”â”¬ â”¬
## â• â•©â•—â”œâ”¤ â””â”¬â”˜
## â•© â•©â””â”€â”˜ â”´ 

$client_secret = 'PE3gNFPgMjCf-8zhfVvFu2n0NNuwkoQ_' #'yeFRoapwmYGitVu8hQwofX-wz_vqpTFJ'
$client_id = 'accessJob' #'CCP_API_Access'
$DomainIAM = 'cagip-iam.prodinfo.gca'



# â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—â–ˆâ–ˆâ•—   â–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ•—   â–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—â–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ•—   â–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—
# â–ˆâ–ˆâ•”â•â•â•â•â•â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â•â•â•â•šâ•â•â–ˆâ–ˆâ•”â•â•â•â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â•â•â•
# â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â–ˆâ–ˆâ•— â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘        â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â–ˆâ–ˆâ•— â–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—
# â–ˆâ–ˆâ•”â•â•â•  â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘â•šâ–ˆâ–ˆâ•—â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘        â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘â•šâ–ˆâ–ˆâ•—â–ˆâ–ˆâ•‘â•šâ•â•â•â•â–ˆâ–ˆâ•‘
# â–ˆâ–ˆâ•‘     â•šâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘ â•šâ–ˆâ–ˆâ–ˆâ–ˆâ•‘â•šâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—   â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â•šâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘ â•šâ–ˆâ–ˆâ–ˆâ–ˆâ•‘â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•‘
# â•šâ•â•      â•šâ•â•â•â•â•â• â•šâ•â•  â•šâ•â•â•â• â•šâ•â•â•â•â•â•   â•šâ•â•   â•šâ•â• â•šâ•â•â•â•â•â• â•šâ•â•  â•šâ•â•â•â•â•šâ•â•â•â•â•â•â•
                                                                          
function Remove-Diacritics {
    param ([String]$src = [String]::Empty)
    $normalized = $src.Normalize( [Text.NormalizationForm]::FormD )
    $sb = new-object Text.StringBuilder
    $normalized.ToCharArray() | ForEach-Object { 
        if ( [Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($_)
        }
    }
    $sb.ToString()
}

## â•”â•— â”Œâ”€â”â”Œâ”€â”â”¬â”€â”â”Œâ”€â”â”¬â”€â”
## â• â•©â•—â”œâ”¤ â”œâ”€â”¤â”œâ”¬â”˜â”œâ”¤ â”œâ”¬â”˜
## â•šâ•â•â””â”€â”˜â”´ â”´â”´â””â”€â””â”€â”˜â”´â””â”€

Function API_Token {
    $response = $null
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/x-www-form-urlencoded")
    $body = "client_id=" + $client_id + "@" + $DomainIAM + "&client_secret=" + $client_secret + "&scope=usercube_api&grant_type=client_credentials"
    $requestAPI = $api + '/connect/token'
    try {
        $response = Invoke-RestMethod $requestAPI -Method 'POST' -Headers $headers -Body $body 
    }
    catch {
        Write-Warning "API_Token StatusCode: $_"
        clear-variable response
    } 
    clear-variable body
    return $response.access_token
}

## â•”â•â•—â”Œâ”€â” â”¬ â”¬â”Œâ”€â”â”¬â”€â”â”¬ â”¬
## â•šâ•â•—â”‚â”€â”¼â”â”‚ â”‚â”œâ”¤ â”œâ”¬â”˜â””â”¬â”˜
## â•šâ•â•â””â”€â”˜â””â””â”€â”˜â””â”€â”˜â”´â””â”€ â”´ 
Function API_Squery_Resource {
    Param([parameter(position = 1, Mandatory = $true)][string]$Token,
        [parameter(position = 2, Mandatory = $true)][string]$EntityType,
        [parameter(position = 3, Mandatory = $true)][string]$Query) 

    $response = $null
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $Token")
    $requestAPI = $api + '/api/Resource/' + $EntityType + '?api-version=1.0&squery=' + $Query + '&Path=%2FCustom%2FResources%2F' + $EntityType + '%2FView&QueryRootEntityType=' + $EntityType 
    try {
        $response = Invoke-RestMethod $requestAPI -Method 'GET' -Headers $headers
    }
    catch {
        # Note that value__ is not a typo.
        Write-Warning "API_Squery_Resource $Query ==> StatusCode: $_"
        clear-variable response
    }
    return $response 
}

Function API_Squery_AccessControl {
    Param([parameter(position = 1, Mandatory = $true)][string]$Token,
        [parameter(position = 2, Mandatory = $true)][string]$AccessType,
        [parameter(position = 3, Mandatory = $true)][string]$Query) 

    $response = $null
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $Token")
    $requestAPI = $api + '/api/AccessControl/' + $AccessType + '?api-version=1.0&squery=' + $Query + '&Path=%2FAccessControl%2F' + $AccessType + '%2FCreate&QueryRootEntityType=' + $AccessType 
    try {
        $response = Invoke-RestMethod $requestAPI -Method 'GET' -Headers $headers
    }
    catch {
        # Note that value__ is not a typo.
        Write-Warning "API_Squery_AccessControl $Query ==> StatusCode: $_"
        clear-variable response
    }
    return $response 
}

Function API_Squery_ProvisioningPolicy {
    Param([parameter(position = 1, Mandatory = $true)][string]$Token,
        [parameter(position = 2, Mandatory = $true)][string]$PolicyType,
        [parameter(position = 3, Mandatory = $true)][string]$Query) 

    $response = $null
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", "Bearer $Token")
    $requestAPI = $api + '/api/ProvisioningPolicy/' + $PolicyType + '?api-version=1.0&squery=' + $Query + '&Path=%2FProvisioningPolicy%2F' + $PolicyType + '%2FQuery'
    try {
        $response = Invoke-RestMethod $requestAPI -Method 'GET' -Headers $headers
    }
    catch {
        # Note that value__ is not a typo.
        Write-Warning "API_Squery_ProvisioningPolicy $Query ==> StatusCode: $_"
        clear-variable response
    }
    return $response 
}

## â•”â•â•—â”€â” â”¬â”¬â”Œâ”€â”â”Œâ”¬â”â”¬â”Œâ”â”Œâ”Œâ”€â”
## â•‘â•£ â”Œâ”´â”¬â”˜â”‚â””â”€â” â”‚ â”‚â”‚â”‚â”‚â”‚ â”¬
## â•šâ•â•â”´ â””â”€â”´â””â”€â”˜ â”´ â”´â”˜â””â”˜â””â”€â”˜

Function Existing_Person {
    Param([parameter(position = 1, Mandatory = $true)][string]$LOGIN) 

    ## initialize
    if (![string]::IsNullOrEmpty($Authorize)) { 
        clear-variable Authorize
    } 
    if (![string]::IsNullOrEmpty($Exist)) { 
        clear-variable Exist
    } 
     

    ##Token
    $Authorize = API_Token
    if ($Authorize) {      
        ##-- Identity
        $squery = 'join MainRecord MainRecord join PresenceState PresenceState top 1 select Id, MainRecord.LastName, EntityTypeId, InternalDisplayName where ((PresenceState.Id=-101 OR PresenceState.Id=-102) AND MainRecord.EmployeeId="' + $LOGIN.Trim() + '")'
        $Exist = API_Squery_Resource -Token $Authorize -EntityType "Person" -Query $squery

        if ($Exist.Result.Count -gt 0) {
            Write-Verbose "Existing_Person : Identity with Id Usercube $LOGIN is  $($Exist.Result.InternalDisplayName)"
            Return ($Exist.Result.Id, $Exist.Result.MainRecord.Id)
        }
        else {
            Write-Verbose "Existing_Person : No Identity with Id Usercube ($LOGIN)"
            Return $null
        }
    }
    else {
        Write-Warning "Existing_Person : Unauthorized"
        Return $null
    }    
}


## â•”â•â•—â”Œâ”¬â”â”Œâ”¬â”  â•”â•â•—â”¬â”€â”â”Œâ”€â”â”Œâ”€â”â”¬â”¬  â”Œâ”€â”â”Œâ”€â”
## â• â•â•£ â”‚â”‚ â”‚â”‚  â• â•â•â”œâ”¬â”˜â”‚ â”‚â”œâ”¤ â”‚â”‚  â”œâ”¤ â””â”€â”
## â•© â•©â”€â”´â”˜â”€â”´â”˜  â•©  â”´â””â”€â””â”€â”˜â””  â”´â”´â”€â”˜â””â”€â”˜â””â”€â”˜

Function API_AssignedProfile {

    Param([parameter(position = 1, Mandatory = $true)][string]$Token,
        [parameter(position = 2, Mandatory = $true)][string]$Body) 
    
    $response = $null
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Content-Type", "application/json;charset=UTF-8")
    $headers.Add("Accept-Encoding", "gzip, deflate, br")
    $headers.Add("Authorization", "Bearer $Token")
    $requestAPI = $api + '/api/AccessControl/AssignedProfile?api-version=1.0'
    # $Body= Remove-Diacritics $Body
    $retry = $false
    try {
        $response = Invoke-RestMethod $requestAPI -Method 'POST' -Headers $headers -Body $Body
    }
    catch {
        Write-Warning "BEFORE RETRY : API_AssignedProfile StatusCode: $_" 
        $retry = $true
    }
    if ($retry) {
        Start-Sleep -s 1
        try {
            $response = Invoke-RestMethod $requestAPI -Method 'POST' -Headers $headers -Body $Body
        }
        catch {        
            # Note that value__ is not a typo.
            Write-Warning "API_AssignedProfile StatusCode: $_" 
            Write-Host $Body
            $response = $null
        }
    }
    return $response 
}
    

# ╔╗╔╔═╗╔═╗
# ║║║╠═╣╚═╗
# ╝╚╝╩ ╩╚═╝
Nas_Mapping

# â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•—  â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ•—   â–ˆâ–ˆâ–ˆâ•—
# â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â•â•â• â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ•— â–ˆâ–ˆâ–ˆâ–ˆâ•‘
# â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ–ˆâ•—â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â–ˆâ–ˆâ–ˆâ–ˆâ•”â–ˆâ–ˆâ•‘
# â–ˆâ–ˆâ•”â•â•â•â• â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘   â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•—â–ˆâ–ˆâ•”â•â•â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘â•šâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘
# â–ˆâ–ˆâ•‘     â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â•šâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â•šâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ–ˆâ•”â•â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘  â–ˆâ–ˆâ•‘â–ˆâ–ˆâ•‘ â•šâ•â• â–ˆâ–ˆâ•‘
# â•šâ•â•     â•šâ•â•  â•šâ•â• â•šâ•â•â•â•â•â•  â•šâ•â•â•â•â•â• â•šâ•â•  â•šâ•â•â•šâ•â•  â•šâ•â•â•šâ•â•     â•šâ•â•

$DirSource = Join-Path -Path $src -ChildPath "AssignedProfiles"
$DirArchive = Join-Path -Path $DirSource -ChildPath "Archives"
$ProfileFiles = Get-ChildItem -Path $DirSource -Filter "*.csv" | Where-Object { $_.Name -like "*Ajout profil d'accès.csv" -or $_.Name -like "*Retrait profil d'accès.csv" }

foreach ($ProfileFile in $ProfileFiles) {
    
    Write-Host $ProfileFile
    try {
        $CSVData = Import-Csv -Path $ProfileFile  -Delimiter ";" -Encoding UTF8 | Where-Object { $_.PSObject.Properties.Value -ne $null }
    }
    catch {
        throw $_
        continue
    }

    ## initialize
    if (![string]::IsNullOrEmpty($Authorize)) { 
        clear-variable Authorize
    } 
    if (![string]::IsNullOrEmpty($U3Id)) { 
        clear-variable U3Id
    }
    if (![string]::IsNullOrEmpty($U3MainRecord)) { 
        clear-variable U3MainRecord
    }
    if (![string]::IsNullOrEmpty($U4Id)) {
        clear-variable U4Id
    }
    if (![string]::IsNullOrEmpty($U4MainRecord)) {
        clear-variable U4MainRecord
    }
    
    $LineNumber = 0 
    :NextOne Foreach ($AskValue in $CSVData) {
        $LineNumber++
        $U3Id, $U3MainRecord = Existing_Person -LOGIN $AskValue.Identity
	    if (![string]::IsNullOrEmpty($AskValue.Manager)) {
		    $U4Id, $U4MainRecord = Existing_Person -LOGIN $AskValue.Manager
	    }
        if ($U3Id.Count -gt 0) {
        
            $Authorize = API_Token
            if ($Authorize) {  
                $body = "{`"Context`":"


                switch ($AskValue.Profil) {
                    'Assistante' {
                        $body = $body + "{`"Dimensions`":{"

                        ##-- Service 
                        if ([string]::IsNullOrEmpty($AskValue.Organization)) { 
                            Write-Warning "Organization of Identity is empty for $AskValue.Identity" 
                            continue NextOne
                        }
                        else {
                            $squery = 'select Id where (Identifier="' + $AskValue.Organization + '")'
                            $Reponse = API_Squery_Resource -Token $Authorize -EntityType "Organization" -Query $squery
                            if ($Reponse.Result.Count -gt 0) {
                                $body = $body + "`"Organization0`":{`"ResourceId`":`"" + $Reponse.Result.Id + "`"}" 
                            }
                            else {
                                Write-Warning ("No Id for Organization : " + $AskValue.Organization)
                                continue NextOne
                            }
                        }

                        ##-- Division 
                        $DIVISION = "70176"
                        if (![string]::IsNullOrEmpty($DIVISION)) { 
                            $squery = 'select Id where (Identifier="' + $DIVISION + '")'
                            $ReponseDiv = API_Squery_Resource -Token $Authorize -EntityType "Division" -Query $squery
                            if ($ReponseDiv.Result.Count -gt 0) {
                                $body = $body + ",`"Division1`":{`"ResourceId`":`"" + $ReponseDiv.Result.Id + "`"}" 
                            }
                            else {
                                Write-Warning ("No Id for Division : " + $DIVISION)
                                continue NextOne
                            }
                        }

                        $body = $body + "}"
                        break
                    }                
                    'Manager' {
                        $body = $body + "{`"Dimensions`":{"

                        ##-- Service 
                        if ([string]::IsNullOrEmpty($AskValue.Organization)) { 
                            Write-Warning "Organization of Identity is empty for $AskValue.Identity" 
                            continue NextOne
                        }
                        else {
                            $squery = 'select Id where (Identifier="' + $AskValue.Organization + '")'
                            $Reponse = API_Squery_Resource -Token $Authorize -EntityType "Organization" -Query $squery
                            if ($Reponse.Result.Count -gt 0) {
                                $body = $body + "`"Organization0`":{`"ResourceId`":`"" + $Reponse.Result.Id + "`"}" 
                            }
                            else {
                                Write-Warning ("No Id for Organization : " + $AskValue.Organization)
                                continue NextOne
                            }
                        }

                        ##-- Division 
                        $DIVISION = "70176"
                        if (![string]::IsNullOrEmpty($DIVISION)) { 
                            $squery = 'select Id where (Identifier="' + $DIVISION + '")'
                            $ReponseDiv = API_Squery_Resource -Token $Authorize -EntityType "Division" -Query $squery
                            if ($ReponseDiv.Result.Count -gt 0) {
                                $body = $body + ",`"Division1`":{`"ResourceId`":`"" + $ReponseDiv.Result.Id + "`"}" 
                            }
                            else {
                                Write-Warning ("No Id for Division : " + $DIVISION)
                                continue NextOne
                            }
                        }

                        ##-- Responsible 
						    ##-- Le manageur est lui mÃªme si la colonne manageur n'est pas renseignÃ©e
					    if (![string]::IsNullOrEmpty($U4MainRecord)) {
						    $body = $body + ",`"Responsible6`":{`"ResourceId`":`"" + $U4MainRecord + "`"}}"
					    }
					    else {
						    $body = $body + ",`"Responsible6`":{`"ResourceId`":`"" + $U3MainRecord + "`"}}"
					    }
					    break
                    }
                    'RoleOfficer2' {
                        $PolicyArg=0
                        if (![string]::IsNullOrEmpty($AskValue.SingleRole)) {
                            $roleValue = $AskValue.SingleRole
                            $roleType = 'SingleRole'
                        } elseif (![string]::IsNullOrEmpty($AskValue.CompositeRole)) {
                            $roleValue = $AskValue.CompositeRole
                            $roleType = 'CompositeRole'
                        } else {
                            Write-Warning ("Missing role for $($AskValue.Identity)")
                            break
                        }
                        $squery = 'select Id where Identifier="' + $roleValue + '"'
                        $Reponse = API_Squery_ProvisioningPolicy -Token $Authorize -PolicyType $roleType -Query $squery
                        if ($Reponse.Result.Count -gt 0) {
                            $body = $body + "{`"" + $roleType + "Id`":`"" + $Reponse.Result.Id + "`""
                            $PolicyArg++
                        }
                        else {
                            Write-Warning ("No Id for $roleType : " + $($AskValue.SingleRole))
                        }

                        if ($PolicyArg -gt 0) {
                            Write-Verbose "Controle for Policy Argument : OK"
                        }   else {
                            Write-Warning ("Any argument for $($AskValue.Identity) : Any Profile")
                            continue NextOne
                        } 
                        break

                    }
                    'RoleOfficerByRole' {
                        $PolicyArg=0
                        if (![string]::IsNullOrEmpty($AskValue.Category)) { 
                            $squery = 'select Id where Identifier="' + $AskValue.Category + '"'
                            $Reponse = API_Squery_ProvisioningPolicy -Token $Authorize -PolicyType "Category" -Query $squery
                            if ($Reponse.Result.Count -gt 0) {
                                $body = $body + "{`"CategoryId`":`"" + $Reponse.Result.Id + "`""
                                $PolicyArg++
                            }
                            else {
                                Write-Warning ("No Id for Category : " + $($AskValue.Category))
                            }
                        }               
                        if ($PolicyArg -gt 0) {
                            Write-Verbose "Controle for Policy Argument : OK"
                        }   else {
                            Write-Warning ("Any argument for $AskValue.Identity : Any Profile")
                            continue NextOne
                        } 
                        break
                    }
                    default {
                        Write-Warning ("Unknown this profile : $($AskValue.Profil)" )
                        continue NextOne
                    }
                }

                ## Id Profile
                $ReturnProfile = API_Squery_AccessControl -Token $Authorize -AccessType "Profile" -Query ("select Id Where Identifier=`"" + $($AskValue.Profil) + "`"")
                if ($ReturnProfile.Result.Count -gt 0) {
                    $body = $body + "},`"ProfileId`":`"" + $($ReturnProfile.Result.Id)
                }
                else {
                    Write-Warning ("Any profil in configuration with $($AskValue.Profil) for $($AskValue.Identity)")
                    continue NextOne
                }


                ## BODY
                $body = $body + "`",`"UserId`":`"" + $U3Id + "`",`"IsDenied`":false,`"AccessState`":16,`"ContextId`":`"1`"}"
                $Reponse = API_AssignedProfile -Token $Authorize -Body $body 
                ## Si retour avec succes
                if (![string]::IsNullOrEmpty($Reponse)) {
                    Write-Host ("Add profil with success (line " + $LineNumber + "/" + $CSVData.count + ") : " + $Reponse ) -ForegroundColor Green
                }
                else {
                    Write-Warning "Error for the profil $($AskValue.Profil) with this body : $body"
                    continue NextOne
                }
            }


            ##-- Purge variables sensibles
            if (![string]::IsNullOrEmpty($U3Id)) { 
                clear-variable U3Id
            }
            if (![string]::IsNullOrEmpty($U3MainRecord)) { 
                clear-variable U3MainRecord
            }                
            if (![string]::IsNullOrEmpty($Reponse)) { 
                clear-variable Reponse
            }
            if (![string]::IsNullOrEmpty($ReponseDiv)) { 
                clear-variable ReponseDiv
            }
            if (![string]::IsNullOrEmpty($Authorize)) { 
                clear-variable Authorize
            }         
            if (![string]::IsNullOrEmpty($ReturnProfile)) { 
                clear-variable ReturnProfile
            }        
            if (![string]::IsNullOrEmpty($squery)) { 
                clear-variable squery
            }        
        }
    }

    $ArchiveFile = Join-Path -Path $DirArchive -ChildPath ((Get-Date).ToString("yyyyMMddHHmmss") + "_" + $ProfileFile)  
    Move-Item -Path $ProfileFile -Destination $ArchiveFile
}


Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Close Add_Profile_API process"
Stop-Transcript | out-null
#####