﻿## PowerShell script for mass Add & Remove Access Profiles integration in STAN (based on CSV source file)
## Usercube V6.1 - 10/10/2024


# ██████╗  █████╗ ██████╗  █████╗ ███╗   ███╗
# ██╔══██╗██╔══██╗██╔══██╗██╔══██╗████╗ ████║
# ██████╔╝███████║██████╔╝███████║██╔████╔██║
# ██╔═══╝ ██╔══██║██╔══██╗██╔══██║██║╚██╔╝██║
# ██║     ██║  ██║██║  ██║██║  ██║██║ ╚═╝ ██║
# ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝

param (
	[switch] $help
	# TODO SUP [parameter(Mandatory = $true)][string] $ProfileFile
)
if ($help) {
# TODO SUP
#	write-host "Add_Profile_API.ps1 -ProfileFile <String> [-help] [-Verbose]
#
#Options:
# -ProfileFile <String> Sets the path of the CSV profiles entries file
#Shared Options:
# -help  Show help information
# -Verbose 
#"
	write-host "Add_Profile_API.ps1 [-help] [-Verbose]

Shared Options:
 -help  Show help information
 -Verbose 
"
	Break
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12, [Net.SecurityProtocolType]::Tls11


# ██╗   ██╗ █████╗ ██████╗ ██╗ █████╗ ██████╗ ██╗     ███████╗███████╗
# ██║   ██║██╔══██╗██╔══██╗██║██╔══██╗██╔══██╗██║     ██╔════╝██╔════╝
# ██║   ██║███████║██████╔╝██║███████║██████╔╝██║     █████╗  ███████╗
# ╚██╗ ██╔╝██╔══██║██╔══██╗██║██╔══██║██╔══██╗██║     ██╔══╝  ╚════██║
#  ╚████╔╝ ██║  ██║██║  ██║██║██║  ██║██████╔╝███████╗███████╗███████║
#   ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝╚══════╝

# Environnement
$EnvironmentPath = Split-Path $PSScriptRoot -parent
. "$EnvironmentPath\Powershell\Environnement.ps1"

## ╦  ┌─┐┌─┐┌─┐
## ║  │ ││ ┬└─┐
## ╩═╝└─┘└─┘└─┘

$date = (Get-Date)
$start = $date.ToString("yyyyMMddHHmmss")
$filetrace = Join-Path -Path $log -ChildPath "Add_Profile_API_$start.log"
Start-Transcript $filetrace | out-null
Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Start Add_Profile_API process"

$DomainIAM = 'cagip-iam.prodinfo.gca'


# ███████╗ ██████╗ ███╗   ██╗ ██████╗████████╗██╗ ██████╗ ███╗   ██╗███████╗
# ██╔════╝██╔═══██╗████╗  ██║██╔════╝╚══██╔══╝██║██╔═══██╗████╗  ██║██╔════╝
# █████╗  ██║   ██║██╔██╗ ██║██║        ██║   ██║██║   ██║██╔██╗ ██║███████╗
# ██╔══╝  ██║   ██║██║╚██╗██║██║        ██║   ██║██║   ██║██║╚██╗██║╚════██║
# ██║     ╚██████╔╝██║ ╚████║╚██████╗   ██║   ██║╚██████╔╝██║ ╚████║███████║
# ╚═╝      ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝

## ╔╗ ┌─┐┌─┐┬─┐┌─┐┬─┐
## ╠╩╗├┤ ├─┤├┬┘├┤ ├┬┘
## ╚═╝└─┘┴ ┴┴└─└─┘┴└─

Function API_Token {
	$response = $null
	$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
	$headers.Add("Content-Type", "application/x-www-form-urlencoded")
	$body = "client_id=" + $clientId + "@" + $DomainIAM + "&client_secret=" + $clientSecret + "&scope=usercube_api&grant_type=client_credentials"
	$requestAPI = $api + '/connect/token'
	try {
		$response = Invoke-RestMethod $requestAPI -Method 'POST' -Headers $headers -Body $body 
	}
	catch {
		Write-Warning "API_Token StatusCode: $_"
		clear-variable response
	} 
	clear-variable body
	return $response.access_token
}

## ╔═╗┌─┐ ┬ ┬┌─┐┬─┐┬ ┬
## ╚═╗│─┼┐│ │├┤ ├┬┘└┬┘
## ╚═╝└─┘└└─┘└─┘┴└─ ┴ 

Function API_Squery_Resource {
	Param([parameter(position = 1, Mandatory = $true)][string]$Token,
		[parameter(position = 2, Mandatory = $true)][string]$EntityType,
		[parameter(position = 3, Mandatory = $true)][string]$Query) 

	$response = $null
	$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
	$headers.Add("Authorization", "Bearer $Token")
	$requestAPI = $api + '/api/Resource/' + $EntityType + '?api-version=1.0&squery=' + $Query + '&Path=%2FCustom%2FResources%2F' + $EntityType + '%2FView&QueryRootEntityType=' + $EntityType 
	try {
		$response = Invoke-RestMethod $requestAPI -Method 'GET' -Headers $headers
	}
	catch {
		# Note that value__ is not a typo.
		Write-Warning "API_Squery_Resource $Query ==> StatusCode: $_"
		clear-variable response
	}
	return $response 
}

Function API_Squery_AccessControl {
	Param([parameter(position = 1, Mandatory = $true)][string]$Token,
		[parameter(position = 2, Mandatory = $true)][string]$AccessType,
		[parameter(position = 3, Mandatory = $true)][string]$Query) 

	$response = $null
	$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
	$headers.Add("Authorization", "Bearer $Token")
	$requestAPI = $api + '/api/AccessControl/' + $AccessType + '?api-version=1.0&squery=' + $Query + '&Path=%2FAccessControl%2F' + $AccessType + '%2FCreate&QueryRootEntityType=' + $AccessType 
	try {
		$response = Invoke-RestMethod $requestAPI -Method 'GET' -Headers $headers
	}
	catch {
		# Note that value__ is not a typo.
		Write-Warning "API_Squery_AccessControl $Query ==> StatusCode: $_"
		clear-variable response
	}
	return $response 
}

Function API_Squery_ProvisioningPolicy {
	Param([parameter(position = 1, Mandatory = $true)][string]$Token,
		[parameter(position = 2, Mandatory = $true)][string]$PolicyType,
		[parameter(position = 3, Mandatory = $true)][string]$Query) 

	$response = $null
	$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
	$headers.Add("Authorization", "Bearer $Token")
	$requestAPI = $api + '/api/ProvisioningPolicy/' + $PolicyType + '?api-version=1.0&squery=' + $Query + '&Path=%2FProvisioningPolicy%2F' + $PolicyType + '%2FQuery'
	try {
		$response = Invoke-RestMethod $requestAPI -Method 'GET' -Headers $headers
	}
	catch {
		# Note that value__ is not a typo.
		Write-Warning "API_Squery_ProvisioningPolicy $Query ==> StatusCode: $_"
		clear-variable response
	}
	return $response 
}

## ╔═╗─┐ ┬┬┌─┐┌┬┐┬┌┐┌┌─┐
## ║╣ ┌┴┬┘│└─┐ │ │││││ ┬
## ╚═╝┴ └─┴└─┘ ┴ ┴┘└┘└─┘

Function Existing_Person {
	Param([parameter(position = 1, Mandatory = $true)][string]$LOGIN) 

	## initialize
	if (![string]::IsNullOrEmpty($Authorize)) { 
		clear-variable Authorize
	} 
	if (![string]::IsNullOrEmpty($Exist)) { 
		clear-variable Exist
	}

	##Token
	$Authorize = API_Token
	if ($Authorize) {
		##-- Identity
		$squery = 'join MainRecord MainRecord join PresenceState PresenceState top 1 select Id, MainRecord.LastName, EntityTypeId, InternalDisplayName where ((PresenceState.Id=-101 OR PresenceState.Id=-102) AND MainRecord.EmployeeId="' + $LOGIN.Trim() + '")'
		$Exist = API_Squery_Resource -Token $Authorize -EntityType "Person" -Query $squery

		if ($Exist.Result.Count -gt 0) {
			Write-Verbose "Existing_Person : Identity with Id Usercube $LOGIN is  $($Exist.Result.InternalDisplayName)"
			Return ($Exist.Result.Id, $Exist.Result.MainRecord.Id)
		}
		else {
			Write-Verbose "Existing_Person : No Identity with Id Usercube ($LOGIN)"
			Return $null
		}
	}
	else {
		Write-Warning "Existing_Person : Unauthorized"
		Return $null
	}
}

## ╔═╗┌┬┐┌┬┐  ╔═╗┬─┐┌─┐┌─┐┬┬  ┌─┐┌─┐
## ╠═╣ ││ ││  ╠═╝├┬┘│ │├┤ ││  ├┤ └─┐
## ╩ ╩─┴┘─┴┘  ╩  ┴└─└─┘└  ┴┴─┘└─┘└─┘

Function API_AssignedProfile {

	Param([parameter(position = 1, Mandatory = $true)][string]$Token,
		[parameter(position = 2, Mandatory = $true)][string]$Body) 

	$response = $null
	$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
	$headers.Add("Content-Type", "application/json;charset=UTF-8")
	$headers.Add("Accept-Encoding", "gzip, deflate, br")
	$headers.Add("Authorization", "Bearer $Token")
	$requestAPI = $api + '/api/AccessControl/AssignedProfile?api-version=1.0'

	$retry = $false
	try {
		$response = Invoke-RestMethod $requestAPI -Method 'POST' -Headers $headers -Body $Body
	}
	catch {
		Write-Warning "BEFORE RETRY : API_AssignedProfile StatusCode: $_" 
		$retry = $true
	}
	if ($retry) {
		Start-Sleep -s 1
		try {
			$response = Invoke-RestMethod $requestAPI -Method 'POST' -Headers $headers -Body $Body
		}
		catch {
			# Note that value__ is not a typo.
			Write-Warning "API_AssignedProfile StatusCode: $_" 
			Write-Host $Body
			$response = $null
		}
	}
	return $response 
}

# ╔╗╔╔═╗╔═╗
# ║║║╠═╣╚═╗
# ╝╚╝╩ ╩╚═╝
Nas_Mapping


# ██████╗ ██████╗  ██████╗  ██████╗ ██████╗  █████╗ ███╗   ███╗███╗   ███╗███████╗
# ██╔══██╗██╔══██╗██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗████╗ ████║████╗ ████║██╔════╝
# ██████╔╝██████╔╝██║   ██║██║  ███╗██████╔╝███████║██╔████╔██║██╔████╔██║█████╗  
# ██╔═══╝ ██╔══██╗██║   ██║██║   ██║██╔══██╗██╔══██║██║╚██╔╝██║██║╚██╔╝██║██╔══╝  
# ██║     ██║  ██║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║ ╚═╝ ██║██║ ╚═╝ ██║███████╗
# ╚═╝     ╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝     ╚═╝╚══════╝

$DirSource = Join-Path -Path $src -ChildPath "AssignedProfiles"
$DirArchive = Join-Path -Path $DirSource -ChildPath "Archives"
$AddProfileFiles = Get-ChildItem -Path $DirSource -Filter "*.csv" | Where-Object { $_.Name -like "*Ajout profil d'accès.csv" }
$RemoveProfileFiles = Get-ChildItem -Path $DirSource -Filter "*.csv" | Where-Object { $_.Name -like "*Retrait profil d'accès.csv" }

#  █████╗  ████████╗ ██████╗ ██╗   ██╗████████╗███████╗
# ██╔══██╗ ╚══██╔══╝██╔═══██╗██║   ██║╚══██╔══╝██╔════╝
# ███████║    ██║   ██║   ██║██║   ██║   ██║   ███████╗
# ██╔══██║██╗ ██║   ██║   ██║██║   ██║   ██║   ╚════██║
# ██║  ██║╚████╔╝   ╚██████╔╝╚██████╔╝   ██║   ███████║
# ╚═╝  ╚═╝ ╚═══╝     ╚═════╝  ╚═════╝    ╚═╝   ╚══════╝

#Traitement des ajouts de profils d'accès
foreach ($ProfileFileA in $AddProfileFiles) {

	#Lecture du fichier CSV
	Write-Host $ProfileFileA
	try {
		$CSVData = Import-Csv -Path $ProfileFileA  -Delimiter ";" -Encoding UTF8 | Where-Object { $_.PSObject.Properties.Value -ne $null }
	}
	catch {
		throw $_
		continue
	}

	#Traitement ligne par ligne du fichier CSV
	$LineNumber = 0 
	:NextOne Foreach ($AskValue in $CSVData) {
		$LineNumber++


		#Purge des variables
		if (![string]::IsNullOrEmpty($UserId)) { 
			clear-variable UserId
		}
		if (![string]::IsNullOrEmpty($UserRecordId)) { 
			clear-variable UserRecordId
		}
		if (![string]::IsNullOrEmpty($ManagerId)) {
			clear-variable ManagerId
		}
		if (![string]::IsNullOrEmpty($ManagerRecordId)) {
			clear-variable ManagerRecordId
		}
		if (![string]::IsNullOrEmpty($Reponse)) { 
			clear-variable Reponse
		}
		if (![string]::IsNullOrEmpty($ReponseDiv)) { 
			clear-variable ReponseDiv
		}
		if (![string]::IsNullOrEmpty($Authorize)) { 
			clear-variable Authorize
		}
		if (![string]::IsNullOrEmpty($ReturnProfile)) { 
			clear-variable ReturnProfile
		}
		if (![string]::IsNullOrEmpty($squery)) { 
			clear-variable squery
		}

		#Recherche de l'utilisateur (Person_Id / PersonRecord_Id)
		$UserId, $UserRecordId = Existing_Person -LOGIN $AskValue.Identity

		#Recherche du Manager (Person_Id / PersonRecord_Id)
		if (![string]::IsNullOrEmpty($AskValue.Manager)) {
			$ManagerId, $ManagerRecordId = Existing_Person -LOGIN $AskValue.Manager
		}

		#Si utilisateur trouvé
		if ($UserId.Count -gt 0) {
			$Authorize = API_Token
			if ($Authorize) {
				$body = "{`"Context`":"

				#Construction du body en fonction du type de profil à ajouter
				switch ($AskValue.Profil) {

					## PROFIL ASSISTANT
					'Assistante' {
						$body = $body + "{`"Dimensions`":{"

						#- Organisation
						if ([string]::IsNullOrEmpty($AskValue.Organization)) { 
							Write-Warning "Organization of Identity is empty for $AskValue.Identity" 
							continue NextOne
						}
						else {
							$squery = 'select Id where (Identifier="' + $AskValue.Organization + '")'
							$Reponse = API_Squery_Resource -Token $Authorize -EntityType "Organization" -Query $squery
							if ($Reponse.Result.Count -gt 0) {
								$body = $body + "`"Organization0`":{`"ResourceId`":`"" + $Reponse.Result.Id + "`"}" 
							}
							else {
								Write-Warning ("No Id for Organization : " + $AskValue.Organization)
								continue NextOne
							}
						}

						#- Division 
						$DIVISION = "70176"
						if (![string]::IsNullOrEmpty($DIVISION)) { 
							$squery = 'select Id where (Identifier="' + $DIVISION + '")'
							$ReponseDiv = API_Squery_Resource -Token $Authorize -EntityType "Division" -Query $squery
							if ($ReponseDiv.Result.Count -gt 0) {
								$body = $body + ",`"Division1`":{`"ResourceId`":`"" + $ReponseDiv.Result.Id + "`"}" 
							}
							else {
								Write-Warning ("No Id for Division : " + $DIVISION)
								continue NextOne
							}
						}

						$body = $body + "}"
						break
					}

					## PROFIL RESPONSABLE OPERATIONNEL
					'Manager' {
						$body = $body + "{`"Dimensions`":{"

						#- Organisation
						if ([string]::IsNullOrEmpty($AskValue.Organization)) { 
							Write-Warning "Organization of Identity is empty for $AskValue.Identity" 
							continue NextOne
						}
						else {
							$squery = 'select Id where (Identifier="' + $AskValue.Organization + '")'
							$Reponse = API_Squery_Resource -Token $Authorize -EntityType "Organization" -Query $squery
							if ($Reponse.Result.Count -gt 0) {
								$body = $body + "`"Organization0`":{`"ResourceId`":`"" + $Reponse.Result.Id + "`"}" 
							}
							else {
								Write-Warning ("No Id for Organization : " + $AskValue.Organization)
								continue NextOne
							}
						}

						#- Division
						$DIVISION = "70176"
						if (![string]::IsNullOrEmpty($DIVISION)) { 
							$squery = 'select Id where (Identifier="' + $DIVISION + '")'
							$ReponseDiv = API_Squery_Resource -Token $Authorize -EntityType "Division" -Query $squery
							if ($ReponseDiv.Result.Count -gt 0) {
								$body = $body + ",`"Division1`":{`"ResourceId`":`"" + $ReponseDiv.Result.Id + "`"}" 
							}
							else {
								Write-Warning ("No Id for Division : " + $DIVISION)
								continue NextOne
							}
						}

						#- Responsable
						#Si la colonne Responsable n'est pas renseignée, le Responsable est l'utilisateur lui-même
						if (![string]::IsNullOrEmpty($ManagerRecordId)) {
							$body = $body + ",`"Responsible6`":{`"ResourceId`":`"" + $ManagerRecordId + "`"}}"
						}
						else {
							$body = $body + ",`"Responsible6`":{`"ResourceId`":`"" + $UserRecordId + "`"}}"
						}
						break
					}

					## PROFIL RESPONSABLE DE ROLE (PAR ROLE SIMPLE)
					'RoleOfficer2' {
						$PolicyArg=0

						#- Role Simple
						if (![string]::IsNullOrEmpty($AskValue.SingleRole)) {
						    $squery = 'select Id where Identifier="' + $AskValue.SingleRole + '"'
						    $Reponse = API_Squery_ProvisioningPolicy -Token $Authorize -PolicyType "SingleRole" -Query $squery
						    if ($Reponse.Result.Count -gt 0) {
							    $body = $body + "{`"SingleRoleId`":`"" + $Reponse.Result.Id + "`""
							    $PolicyArg++
						    }
						    else {
							    Write-Warning ("No Id for SingleRole : " + $($AskValue.SingleRole))
						    }
						} else {
							Write-Warning ("Missing role for $($AskValue.Identity)")
						}

						if ($PolicyArg -gt 0) {
							Write-Verbose "Controle for Policy Argument : OK"
						}   else {
							Write-Warning ("Any argument for $($AskValue.Identity) : Any Profile")
							continue NextOne
						} 
						break
					}

					## PROFIL RESPONSABLE DE ROLE (PAR ROLE COMPOSE)
					'RoleOfficerComposite' {
						$PolicyArg=0

						#- Role Composé
						if (![string]::IsNullOrEmpty($AskValue.CompositeRole)) {
						    $squery = 'select Id where Identifier="' + $AskValue.CompositeRole + '"'
						    $Reponse = API_Squery_ProvisioningPolicy -Token $Authorize -PolicyType "CompositeRole" -Query $squery
						    if ($Reponse.Result.Count -gt 0) {
							    $body = $body + "{`"CompositeRoleId`":`"" + $Reponse.Result.Id + "`""
							    $PolicyArg++
						    }
						    else {
							    Write-Warning ("No Id for Composite Role : " + $($AskValue.CompositeRole))
						    }
						} else {
							Write-Warning ("Missing role for $($AskValue.Identity)")
						}

						if ($PolicyArg -gt 0) {
							Write-Verbose "Controle for Policy Argument : OK"
						}   else {
							Write-Warning ("Any argument for $($AskValue.Identity) : Any Profile")
							continue NextOne
						} 
						break
					}

					## PROFIL RESPONSABLE DE ROLE (PAR CATEGORIE)
					'RoleOfficerByRole' {
						$PolicyArg=0

						#- Catégorie
						if (![string]::IsNullOrEmpty($AskValue.Category)) { 
							$squery = 'select Id where Identifier="' + $AskValue.Category + '"'
							$Reponse = API_Squery_ProvisioningPolicy -Token $Authorize -PolicyType "Category" -Query $squery
							if ($Reponse.Result.Count -gt 0) {
								$body = $body + "{`"CategoryId`":`"" + $Reponse.Result.Id + "`""
								$PolicyArg++
							}
							else {
								Write-Warning ("No Id for Category : " + $($AskValue.Category))
							}
						}
						if ($PolicyArg -gt 0) {
							Write-Verbose "Controle for Policy Argument : OK"
						}   else {
							Write-Warning ("Any argument for $AskValue.Identity : Any Profile")
							continue NextOne
						} 
						break
					}
					default {
						Write-Warning ("Unknown this profile : $($AskValue.Profil)" )
						continue NextOne
					}
				}

				#Recherche de l'Id du type de profil d'accès
				$ReturnProfile = API_Squery_AccessControl -Token $Authorize -AccessType "Profile" -Query ("select Id Where Identifier=`"" + $($AskValue.Profil) + "`"")
				if ($ReturnProfile.Result.Count -gt 0) {
					$body = $body + "},`"ProfileId`":`"" + $($ReturnProfile.Result.Id)
				}
				else {
					Write-Warning ("Any profil in configuration with $($AskValue.Profil) for $($AskValue.Identity)")
					continue NextOne
				}

				#Finalisation du body
				$body = $body + "`",`"UserId`":`"" + $UserId + "`",`"IsDenied`":false,`"AccessState`":16,`"ContextId`":`"1`"}"

				#Execution de la requête d'ajout du profil
				$Reponse = API_AssignedProfile -Token $Authorize -Body $body 
				if (![string]::IsNullOrEmpty($Reponse)) {
					Write-Host ("Add profil with success (line " + $LineNumber + "/" + $CSVData.count + ") : " + $Reponse ) -ForegroundColor Green
				}
				else {
					Write-Warning "Add profil failed (line " + $LineNumber + "/" + $CSVData.count + ") : " + $Reponse
					continue NextOne
				}
			}
		}
	}

	#Archivage du fichier CSV
	$ArchiveFile = Join-Path -Path $DirArchive -ChildPath ((Get-Date).ToString("yyyyMMddHHmmss") + "_" + $ProfileFileA.Name)  
	Move-Item -Path $ProfileFileA.FullName -Destination $ArchiveFile
}

# ██████╗ ███████╗████████╗██████╗  █████╗ ██╗████████╗███████╗
# ██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██║╚══██╔══╝██╔════╝
# ██████╔╝█████╗     ██║   ██████╔╝███████║██║   ██║   ███████╗
# ██╔══██╗██╔══╝     ██║   ██╔══██╗██╔══██║██║   ██║   ╚════██║
# ██║  ██║███████╗   ██║   ██║  ██║██║  ██║██║   ██║   ███████║
# ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ╚═╝   ╚══════╝

#Traitement des retraits de profils d'accès
foreach ($ProfileFileR in $RemoveProfileFiles) {

	#Lecture du fichier CSV
	Write-Host $ProfileFileR
	try {
		$CSVData = Import-Csv -Path $ProfileFileR  -Delimiter ";" -Encoding UTF8 | Where-Object { $_.PSObject.Properties.Value -ne $null }
	}
	catch {
		throw $_
		continue
	}

	#Traitement ligne par ligne du CSV
	$LineNumber = 0 
	:NextOne Foreach ($AskValue in $CSVData) {
		$LineNumber++

		#Purge des variables
		if (![string]::IsNullOrEmpty($UserId)) {
			clear-variable UserId
		}
		if (![string]::IsNullOrEmpty($UserRecordId)) {
			clear-variable UserRecordId
		}
		if (![string]::IsNullOrEmpty($ManagerId)) {
			clear-variable ManagerId
		}
		if (![string]::IsNullOrEmpty($ManagerRecordId)) {
			clear-variable ManagerRecordId
		}
		if (![string]::IsNullOrEmpty($Authorize)) {
			clear-variable Authorize
		}
		if (![string]::IsNullOrEmpty($squery)) {
			clear-variable squery
		}
		if (![string]::IsNullOrEmpty($AssignedProfile)) {
			clear-variable AssignedProfile
		}
		if (![string]::IsNullOrEmpty($IdRoleToDelete)) {
			clear-variable IdRoleToDelete
		}
		if (![string]::IsNullOrEmpty($DeleteResponse)) {
			clear-variable DeleteResponse
		}

		#Recherche de l'utilisateur (Person_Id / PersonRecord_Id)
		$UserId, $UserRecordId = Existing_Person -LOGIN $AskValue.Identity

		#Recherche du Manager (Person_Id / PersonRecord_Id) #TODO SUP
		if (![string]::IsNullOrEmpty($AskValue.Manager)) {
			$ManagerId, $ManagerRecordId = Existing_Person -LOGIN $AskValue.Manager
		}

		if ($UserId.Count -gt 0) {
			$Authorize = API_Token
			if ($Authorize) {
				$body = "{`"Context`":"

				#Recherche du profil existant : construction de la requête squery à partir des éléments du CSV
				$searchProfileQuery = "join Profile p join User u join Context c join c.CompositeRole ccr join c.SingleRole csr join c.ResourceType crt join c.Category cc join c.DimensionOrganization0 d0 join c.DimensionDivision1 d1 join c.DimensionEmployeeCategory2 d2 join c.DimensionDomaineAD3 d3 join c.DimensionZoeMigrationStatus4 d4 join c.DimensionIsVDI5 d5 join c.DimensionResponsible6 d6 join c.DimensionEmployeeType7 d7 join c.DimensionLocalisation8 d8 join c.DimensionSite9 d9 join c.DimensionIdentityType10 d10 join c.DimensionRed01MigrationStatus11 d11 select ProfileId, UserId, ContextId, IsDenied, AccessState, StartDate, EndDate, Email, p.Id, p.Identifier, p.DisplayName, u.InternalDisplayName, ccr.Id, ccr.DisplayName, ccr.FullName, csr.Id, csr.DisplayName, csr.FullName, crt.Id, crt.DisplayName, crt.FullName, cc.Id, cc.DisplayName, cc.FullName, d0.InternalDisplayName, d1.InternalDisplayName, d2.InternalDisplayName, d3.InternalDisplayName, d4.InternalDisplayName, d5.InternalDisplayName, d6.InternalDisplayName, d7.InternalDisplayName, d8.InternalDisplayName, d9.InternalDisplayName, d10.InternalDisplayName, d11.InternalDisplayName"

				#Conditions Id utilisateur + Type de profil
				$searchProfileQuery += " where (UserId=" + $UserId
				$searchProfileQuery += " AND p.Identifier=`"" + $AskValue.Profil + "`""

				switch ($AskValue.Profil) {
					## PROFIL RESPONSABLE OPERATIONNEL : condition Organisation
					'Manager' {
						$searchProfileQuery += " AND d0.Identifier=`"" + $AskValue.Organization + "`""
					}
					## PROFIL ASSISTANT : condition Organisation
					'Assistante' {
						$searchProfileQuery += " AND d0.Identifier=`"" + $AskValue.Organization + "`""
					}
					## PROFIL RESPONSABLE DE ROLE (PAR CATEGORIE) : condition Categorie du rôle
					'RoleOfficerByRole' {
						$searchProfileQuery += " AND cc.Identifier=`"" + $AskValue.Category + "`""
					}
					## PROFIL RESPONSABLE DE ROLE (PAR ROLE) : condition rôle simple / composé
					'RoleOfficer2' {
						if ($AskValue.SingleRole) {
							$searchProfileQuery += " AND csr.Identifier=`"" + $AskValue.SingleRole + "`""
						}
						elseif ($AskValue.CompositeRole) {
							$searchProfileQuery += " AND ccr.Identifier=`"" + $AskValue.CompositeRole + "`""
						}
						else {
							Write-Warning "ERROR"
						}
						#$searchProfileQuery += " AND (csr.Identifier=`"" + $AskValue.SingleRole + "`" OR ccr.Identifier=`"" + $AskValue.CompositeRole + "`")"
					}
					default {
						Write-Warning ("Unknown this profile : $($AskValue.Profil)" )
						continue NextOne
					}
				}
				$searchProfileQuery += ") order by p.DisplayName asc, Id asc"

				#Recherche du profil : execution de la requête squery
				$AssignedProfile = API_Squery_AccessControl -Token $Authorize -AccessType "AssignedProfile" -Query $searchProfileQuery

				#Suppression du profil : si résultat unique
				if ($AssignedProfile.Result.Count -eq 1) {
					$IdRoleToDelete = $AssignedProfile.Result.Id
					$DeleteResponse = API_DeleteAssignedProfile -Token $Authorize -ProfileId $IdRoleToDelete
					# Si retour avec succes
					if (![string]::IsNullOrEmpty($DeleteResponse)) {
						Write-Host ("Delete profil with success (line " + $LineNumber + "/" + $CSVData.count + ") : " + $DeleteResponse )
					}
					else {
						Write-Warning ("Delete profil failed (line " + $LineNumber + "/" + $CSVData.count + ") : " + $DeleteResponse )
						continue NextOne
					}
				}
				else {
					Write-Warning ("Delete profil failed (line " + $LineNumber + "/" + $CSVData.count + ") : 0 or more than 1 profile found with these information ")
				}
			}
		}
		else {
			Write-Warning ("Delete profil failed (line " + $LineNumber + "/" + $CSVData.count + ") : user not found ")
		}
	}

	#Archivage du fichier CSV
	$ArchiveFile = Join-Path -Path $DirArchive -ChildPath ((Get-Date).ToString("yyyyMMddHHmmss") + "_" + $ProfileFileR.Name)  
	Move-Item -Path $ProfileFileR.FullName -Destination $ArchiveFile
}


Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] Close Add_Profile_API process"
Stop-Transcript | out-null
#####